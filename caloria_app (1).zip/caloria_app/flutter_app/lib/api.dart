import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

// Emulador Android usa 10.0.2.2. Em aparelho real: --dart-define=API_URL=http://SEU_IP:8000
const baseUrl = String.fromEnvironment('API_URL', defaultValue: 'http://10.0.2.2:8000');
const defaultWeightKg = 90.0; // TODO: vir do perfil do usuário

class Api {
  static Future<Map<String, dynamic>> product(String code) async {
    final r = await http.get(Uri.parse('$baseUrl/food/barcode/$code'));
    if (r.statusCode != 200) throw Exception('Produto não encontrado');
    return jsonDecode(utf8.decode(r.bodyBytes));
  }

  static Future<Map<String, dynamic>> analyzePhoto(File file) async {
    final req = http.MultipartRequest('POST', Uri.parse('$baseUrl/food/photo'))
      ..files.add(await http.MultipartFile.fromPath('file', file.path));
    final res = await http.Response.fromStream(await req.send());
    if (res.statusCode != 200) throw Exception('Falha ao analisar a foto');
    return jsonDecode(utf8.decode(res.bodyBytes));
  }

  static Future<Map<String, dynamic>> plan(double kcal, {String level = 'beginner'}) async {
    final uri = Uri.parse('$baseUrl/exercises/plan').replace(queryParameters: {
      'kcal': kcal.toString(),
      'weight_kg': defaultWeightKg.toString(),
      'level': level,
    });
    final r = await http.get(uri);
    if (r.statusCode != 200) throw Exception('Erro ao gerar plano');
    return jsonDecode(utf8.decode(r.bodyBytes));
  }
}
