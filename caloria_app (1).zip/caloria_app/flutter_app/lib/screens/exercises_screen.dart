import 'package:flutter/material.dart';
import '../api.dart';

class ExercisesScreen extends StatefulWidget {
  const ExercisesScreen({super.key});
  @override
  State<ExercisesScreen> createState() => _ExercisesScreenState();
}

class _ExercisesScreenState extends State<ExercisesScreen> {
  double kcal = 150;
  String level = 'beginner';
  Map<String, dynamic>? plan;
  bool loading = false;

  Future<void> _load() async {
    setState(() => loading = true);
    try {
      plan = await Api.plan(kcal, level: level);
    } catch (_) {}
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
        Text('Queimar ${kcal.round()} kcal', style: Theme.of(context).textTheme.titleLarge),
        Slider(value: kcal, min: 50, max: 600, divisions: 11, onChanged: (v) => setState(() => kcal = v)),
        SegmentedButton<String>(
          segments: const [
            ButtonSegment(value: 'beginner', label: Text('Leve')),
            ButtonSegment(value: 'intermediate', label: Text('Médio')),
            ButtonSegment(value: 'advanced', label: Text('Forte')),
          ],
          selected: {level},
          onSelectionChanged: (s) => setState(() => level = s.first),
        ),
        const SizedBox(height: 12),
        FilledButton(onPressed: loading ? null : _load, child: const Text('Gerar treino')),
        if (plan != null) ...[
          const SizedBox(height: 12),
          Text('Total: ${plan!['total_minutes']} min'),
          for (final s in plan!['steps'])
            Card(child: ListTile(title: Text('${s['name']} — ${s['minutes']} min (~${s['kcal']} kcal)'), subtitle: Text(s['how']))),
        ],
      ]);
}
