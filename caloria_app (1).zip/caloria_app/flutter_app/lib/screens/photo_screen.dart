import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../api.dart';

/// Foto do prato -> estimativa de calorias -> plano de exercícios para compensar.
class PhotoScreen extends StatefulWidget {
  const PhotoScreen({super.key});
  @override
  State<PhotoScreen> createState() => _PhotoScreenState();
}

class _PhotoScreenState extends State<PhotoScreen> {
  File? photo;
  Map<String, dynamic>? result;
  Map<String, dynamic>? plan;
  bool loading = false;
  String? error;

  Future<void> _pick() async {
    final x = await ImagePicker().pickImage(source: ImageSource.camera, maxWidth: 1280, imageQuality: 80);
    if (x == null) return;
    setState(() { photo = File(x.path); loading = true; error = null; result = null; plan = null; });
    try {
      result = await Api.analyzePhoto(photo!);
    } catch (e) {
      error = 'Não consegui analisar a foto. Tente de novo.';
    }
    if (mounted) setState(() => loading = false);
  }

  Future<void> _plan() async {
    final p = await Api.plan((result!['total_kcal'] as num).toDouble().clamp(50, 1500).toDouble());
    setState(() => plan = p);
  }

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
        FilledButton.icon(onPressed: loading ? null : _pick, icon: const Icon(Icons.photo_camera), label: const Text('Fotografar prato')),
        if (photo != null) Padding(padding: const EdgeInsets.only(top: 12), child: ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.file(photo!, height: 200, fit: BoxFit.cover))),
        if (loading) const Padding(padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator())),
        if (error != null) Text(error!, style: const TextStyle(color: Colors.red)),
        if (result != null) ...[
          const SizedBox(height: 12),
          Text('Total estimado: ${result!['total_kcal']} kcal', style: Theme.of(context).textTheme.headlineSmall),
          Text('Confiança: ${result!['confidence']} (valores aproximados)'),
          for (final i in result!['items']) ListTile(dense: true, title: Text(i['name']), trailing: Text('${i['grams']}g • ${i['kcal']} kcal')),
          OutlinedButton(onPressed: _plan, child: const Text('Como queimar isso em casa?')),
        ],
        if (plan != null) ...[
          const Divider(),
          Text('Plano: ${plan!['total_minutes']} min'),
          for (final s in plan!['steps']) ListTile(title: Text('${s['name']} — ${s['minutes']} min'), subtitle: Text(s['how'])),
        ],
      ]);
}
