import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import '../api.dart';

/// Escaneia produtos no mercado e compara (ex.: duas maioneses).
class ScanScreen extends StatefulWidget {
  const ScanScreen({super.key});
  @override
  State<ScanScreen> createState() => _ScanScreenState();
}

class _ScanScreenState extends State<ScanScreen> {
  final items = <Map<String, dynamic>>[];
  bool busy = false;
  String? error;

  Future<void> _onDetect(BarcodeCapture cap) async {
    final code = cap.barcodes.isEmpty ? null : cap.barcodes.first.rawValue;
    if (busy || code == null) return;
    setState(() { busy = true; error = null; });
    try {
      final p = await Api.product(code);
      if (!items.any((e) => e['barcode'] == p['barcode'])) items.add(p);
    } catch (_) {
      error = 'Produto não encontrado';
    }
    await Future.delayed(const Duration(milliseconds: 1500));
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) {
    final sorted = [...items]..sort((a, b) => (a['kcal_100g'] as num).compareTo(b['kcal_100g'] as num));
    return Column(children: [
      SizedBox(height: 240, child: MobileScanner(onDetect: _onDetect)),
      if (error != null) Padding(padding: const EdgeInsets.all(8), child: Text(error!, style: const TextStyle(color: Colors.red))),
      Expanded(
        child: sorted.isEmpty
            ? const Center(child: Text('Aponte a câmera para o código de barras'))
            : ListView.builder(
                itemCount: sorted.length,
                itemBuilder: (_, i) {
                  final p = sorted[i];
                  final best = i == 0 && sorted.length > 1;
                  return Card(
                    color: best ? Colors.green.shade100 : null,
                    child: ListTile(
                      title: Text(p['name']),
                      subtitle: Text('${p['brand'] ?? ''}\n${p['kcal_100g']} kcal / 100g'
                          '${p['sugar_100g'] != null ? '  •  açúcar ${p['sugar_100g']}g' : ''}'),
                      isThreeLine: true,
                      trailing: best ? const Chip(label: Text('Menos calórico')) : null,
                      leading: IconButton(icon: const Icon(Icons.close), onPressed: () => setState(() => items.remove(p))),
                    ),
                  );
                },
              ),
      ),
    ]);
  }
}
