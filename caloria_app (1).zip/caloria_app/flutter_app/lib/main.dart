import 'package:flutter/material.dart';
import 'screens/scan_screen.dart';
import 'screens/photo_screen.dart';
import 'screens/exercises_screen.dart';

void main() => runApp(const CaloriaApp());

class CaloriaApp extends StatelessWidget {
  const CaloriaApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Caloria',
        theme: ThemeData(colorSchemeSeed: Colors.green, useMaterial3: true),
        home: const Shell(),
      );
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int i = 0;
  final pages = const [ScanScreen(), PhotoScreen(), ExercisesScreen()];

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(child: pages[i]),
        bottomNavigationBar: NavigationBar(
          selectedIndex: i,
          onDestinationSelected: (v) => setState(() => i = v),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.qr_code_scanner), label: 'Mercado'),
            NavigationDestination(icon: Icon(Icons.photo_camera), label: 'Prato'),
            NavigationDestination(icon: Icon(Icons.fitness_center), label: 'Exercícios'),
          ],
        ),
      );
}
