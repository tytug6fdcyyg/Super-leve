# Caloria

## Backend
```
cd backend
cp .env.example .env   # coloque ANTHROPIC_API_KEY
pip install -r requirements.txt
export $(cat .env | xargs) && uvicorn app.main:app --reload
```
Docs: http://localhost:8000/docs  (ou `docker compose up --build` na raiz)

## Flutter
```
cd flutter_app
flutter create . --platforms=android,ios
flutter pub get
flutter run --dart-define=API_URL=http://SEU_IP:8000
```
Permissões: câmera (AndroidManifest `CAMERA`; iOS `NSCameraUsageDescription`).
