import base64
import json
import re

import httpx

from ..config import ANTHROPIC_API_KEY, VISION_MODEL

PROMPT = (
    "Analise a foto de comida. Identifique cada alimento visível e estime porção em gramas "
    "e calorias. Responda SOMENTE com JSON, sem texto extra, neste formato: "
    '{"items":[{"name":"...","grams":0,"kcal":0}],"confidence":"baixa|media|alta"}'
)


async def analyze_food_photo(image_bytes: bytes, media_type: str) -> dict:
    body = {
        "model": VISION_MODEL,
        "max_tokens": 1000,
        "messages": [{
            "role": "user",
            "content": [
                {"type": "image", "source": {"type": "base64", "media_type": media_type,
                                              "data": base64.b64encode(image_bytes).decode()}},
                {"type": "text", "text": PROMPT},
            ],
        }],
    }
    headers = {"x-api-key": ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01",
               "content-type": "application/json"}
    async with httpx.AsyncClient(timeout=60) as client:
        r = await client.post("https://api.anthropic.com/v1/messages", json=body, headers=headers)
    r.raise_for_status()
    text = "".join(b.get("text", "") for b in r.json()["content"])
    text = re.sub(r"```json|```", "", text).strip()
    result = json.loads(text)
    result["total_kcal"] = round(sum(i.get("kcal", 0) for i in result["items"]))
    return result
