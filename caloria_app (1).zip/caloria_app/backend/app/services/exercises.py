import random

# MET aproximado (Compendium of Physical Activities). impact: low | medium | high
CATALOG = [
    {"id": "alongamento", "name": "Alongamento completo", "met": 2.3, "impact": "low", "how": "Alongue pescoço, ombros, costas e pernas, 20s cada."},
    {"id": "caminhada", "name": "Caminhada no lugar", "met": 3.0, "impact": "low", "how": "Eleve os joelhos em ritmo confortável."},
    {"id": "agachamento_cadeira", "name": "Agachamento na cadeira", "met": 3.5, "impact": "low", "how": "Sente e levante da cadeira sem usar as mãos."},
    {"id": "flexao_parede", "name": "Flexão na parede", "met": 3.8, "impact": "low", "how": "Mãos na parede, afaste os pés e flexione os braços."},
    {"id": "polichinelo_sem_salto", "name": "Polichinelo sem salto", "met": 4.0, "impact": "low", "how": "Abra e feche braços e pernas alternando os passos."},
    {"id": "flexao_joelhos", "name": "Flexão com joelhos apoiados", "met": 4.0, "impact": "medium", "how": "Joelhos no chão, corpo reto da cabeça aos joelhos."},
    {"id": "polichinelo", "name": "Polichinelo", "met": 7.7, "impact": "high", "how": "Saltos leves abrindo e fechando braços e pernas."},
    {"id": "flexao", "name": "Flexão tradicional", "met": 8.0, "impact": "high", "how": "Corpo reto, desça o peito até perto do chão."},
]

LEVELS = {"beginner": {"low"}, "intermediate": {"low", "medium"}, "advanced": {"low", "medium", "high"}}


def kcal_per_min(met: float, weight_kg: float) -> float:
    return met * 3.5 * weight_kg / 200


def build_plan(kcal_to_burn: float, weight_kg: float, level: str) -> dict:
    allowed = LEVELS.get(level, LEVELS["beginner"])
    pool = [e for e in CATALOG if e["impact"] in allowed]
    picks = random.sample(pool, k=min(3, len(pool)))
    share = kcal_to_burn / len(picks)
    steps, total_min = [], 0
    for e in picks:
        minutes = max(2, min(20, round(share / kcal_per_min(e["met"], weight_kg))))
        total_min += minutes
        steps.append({**e, "minutes": minutes,
                      "kcal": round(minutes * kcal_per_min(e["met"], weight_kg))})
    return {"target_kcal": kcal_to_burn, "total_minutes": total_min, "steps": steps}
