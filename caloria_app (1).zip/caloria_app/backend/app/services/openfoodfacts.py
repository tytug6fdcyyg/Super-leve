import httpx

from ..config import OFF_URL


async def get_product(barcode: str) -> dict | None:
    """Busca produto por código de barras no Open Food Facts."""
    params = {"fields": "product_name,brands,nutriments,serving_size,image_front_small_url"}
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(f"{OFF_URL}/{barcode}.json", params=params,
                             headers={"User-Agent": "CaloriaApp/0.1"})
    if r.status_code != 200:
        return None
    data = r.json()
    if data.get("status") != 1:
        return None
    p = data["product"]
    n = p.get("nutriments", {})
    kcal = n.get("energy-kcal_100g")
    if kcal is None:
        return None
    return {
        "barcode": barcode,
        "name": p.get("product_name") or "Sem nome",
        "brand": p.get("brands"),
        "kcal_100g": round(float(kcal), 1),
        "fat_100g": n.get("fat_100g"),
        "sugar_100g": n.get("sugars_100g"),
        "protein_100g": n.get("proteins_100g"),
        "serving_size": p.get("serving_size"),
        "image": p.get("image_front_small_url"),
    }
