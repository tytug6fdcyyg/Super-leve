from fastapi import APIRouter, File, HTTPException, UploadFile
from pydantic import BaseModel

from ..services import openfoodfacts, vision

router = APIRouter()


@router.get("/barcode/{code}")
async def by_barcode(code: str):
    product = await openfoodfacts.get_product(code)
    if not product:
        raise HTTPException(404, "Produto não encontrado")
    return product


class CompareIn(BaseModel):
    barcodes: list[str]


@router.post("/compare")
async def compare(body: CompareIn):
    """Compara produtos (ex.: duas maioneses) e ordena do menos para o mais calórico."""
    found = []
    for c in body.barcodes:
        p = await openfoodfacts.get_product(c)
        if p:
            found.append(p)
    found.sort(key=lambda p: p["kcal_100g"])
    return {"best": found[0] if found else None, "ranking": found}


@router.post("/photo")
async def from_photo(file: UploadFile = File(...)):
    if not (file.content_type or "").startswith("image/"):
        raise HTTPException(400, "Envie uma imagem")
    try:
        return await vision.analyze_food_photo(await file.read(), file.content_type)
    except Exception as e:
        raise HTTPException(502, f"Falha ao analisar foto: {e}")
