from typing import Literal

from fastapi import APIRouter
from pydantic import BaseModel, Field

router = APIRouter()


class ProfileIn(BaseModel):
    sex: Literal["m", "f"]
    age: int = Field(ge=16, le=90)
    weight_kg: float = Field(ge=30, le=300)
    height_cm: float = Field(ge=120, le=230)


@router.post("/goal")
def daily_goal(p: ProfileIn):
    """Meta diária moderada (Mifflin-St Jeor, atividade leve, déficit de 15%, com piso de segurança)."""
    bmr = 10 * p.weight_kg + 6.25 * p.height_cm - 5 * p.age + (5 if p.sex == "m" else -161)
    tdee = bmr * 1.375
    floor = 1500 if p.sex == "m" else 1200
    goal = max(round(tdee * 0.85), floor)
    return {"tdee": round(tdee), "daily_kcal_goal": goal,
            "note": "Estimativa geral. Consulte médico ou nutricionista antes de iniciar dieta."}
