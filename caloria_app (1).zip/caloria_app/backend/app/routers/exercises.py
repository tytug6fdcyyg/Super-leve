from fastapi import APIRouter, Query

from ..services import exercises

router = APIRouter()


@router.get("/plan")
def plan(kcal: float = Query(..., gt=0, le=1500), weight_kg: float = Query(80, ge=30, le=300),
         level: str = "beginner"):
    return exercises.build_plan(kcal, weight_kg, level)


@router.get("/catalog")
def catalog():
    return exercises.CATALOG
