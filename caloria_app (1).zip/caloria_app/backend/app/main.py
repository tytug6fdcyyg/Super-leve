from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .routers import exercises, food, profile

app = FastAPI(title="Caloria API", version="0.1.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# Monólito modular: cada router pode virar um microservice depois.
app.include_router(food.router, prefix="/food", tags=["food"])
app.include_router(exercises.router, prefix="/exercises", tags=["exercises"])
app.include_router(profile.router, prefix="/profile", tags=["profile"])


@app.get("/health")
def health():
    return {"status": "ok"}
