import os

ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
VISION_MODEL = os.getenv("VISION_MODEL", "claude-sonnet-5-5")
OFF_URL = "https://world.openfoodfacts.org/api/v2/product"
